#include <stdio.h>


void deleteCourier(char* name){
    FILE *fp = fopen("couriers.txt", "r");
    FILE *temp = fopen("temp.txt", "w");
    char line[100];
    while(fgets(line, 100, fp) != NULL){
        if(strstr(line, name) == NULL){
            fprintf(temp, "%s", line);
        }
    }
    
    fclose(fp);
    fclose(temp);
    temp = fopen("temp.txt", "r");
    fp = fopen("couriers.txt", "w");
    char c = fgetc(temp);
    while(c != EOF){
        fputc(c, fp);
        c = fgetc(temp);
    }
    fclose(fp);
    fclose(temp);
    printf("Courier deleted successfully.\n");
}

void updateCourier(char* name){
    FILE *fp = fopen("couriers.txt", "r");
    FILE *temp = fopen("temp.txt", "w");
    char line[100];
    while(fgets(line, 100, fp) != NULL){
        if(strstr(line, name) == NULL){
            fprintf(temp, "%s", line);
        }
        else{
            printf("Please enter the new address: ");
            char address[100];
            scanf("%s", address);
            printf("Please enter the new phone number: ");
            char phone[100];
            scanf("%s", phone);
            fprintf(temp, "%s %s %s\n", name, phone, address);
        }
    }
    fclose(fp);
    fclose(temp);
    fp = fopen("couriers.txt", "w");
    temp = fopen("temp.txt", "r");
    char c = fgetc(temp);
    while(c != EOF){
        fputc(c, fp);
        c = fgetc(temp);
    }
    fclose(fp);
    fclose(temp);
    printf("Courier updated successfully.\n");
}

void deleteUpdateCourier(){
    FILE *fp = fopen("couriers.txt", "r+");
    if(fp == NULL){
        printf("No courier records found.\n");
        return;
    }
    printf("Please enter the name of the courier you wish to delete/update: ");
    char name[100];
    scanf("%s", name);
    int found = 0;
    while(!feof(fp)){
        char Cname[100], address[100], phone[100];
        fscanf(fp, "%s %s %s", Cname, address, phone);
        if(strcmp(name, Cname) == 0){
            found = 1;
        }
    }
    if(!found){
        printf("No courier found with the name %s.\n", name);
        return;
    }

    printf("Please select an option:\n");
    printf("1. Delete courier\n");
    printf("2. Update courier\n");
    printf("Please enter your choice: ");
    int choice;
    scanf("%d", &choice);
    switch(choice){
        case 1:
            deleteCourier(name);
            break;
        case 2:
            updateCourier(name);
            break;
        default:
            printf("Invalid choice. Please try again.\n");
            deleteUpdateCourier();
            break;
    }
    fclose(fp);
}
