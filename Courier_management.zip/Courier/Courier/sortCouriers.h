#include <stdio.h>
#include <string.h>

void sortCouriers(){
    FILE *fp = fopen("couriers.txt", "r");
    //declare a string array to store the details of courier in name + phone + address format where the total size is less than 300
    char couriers[300][300];
    //iterate through the file and store the details of each courier in the string array
    int i = 0;
    while(!feof(fp)){
        char name[100], address[100], phone[100];
        fscanf(fp, "%s %s %s", name, phone, address);
        strcpy(couriers[i], name);
        strcat(couriers[i], " ");
        strcat(couriers[i], phone);
        strcat(couriers[i], " ");
        strcat(couriers[i], address);
        i++;
    } 
	int j,k;  
    //sort the string array using bubble sort
    for(j = 0; j < i - 1; j++)
	{
        for(k = 0; k < i - 1 - j - 1; k++){
            if(strcmp(couriers[k], couriers[k+1]) > 0){
                char temp[300];
                strcpy(temp, couriers[k]);
                strcpy(couriers[k], couriers[k+1]);
                strcpy(couriers[k+1], temp);
            }
        }
    }
    fclose(fp);
    //write the sorted string array to the file
    
    fp = fopen("couriers.txt", "w");
    for( j = 0; j < i - 1; j++){
        fprintf(fp, "%s\n", couriers[j]);
    }
    fclose(fp);
}
