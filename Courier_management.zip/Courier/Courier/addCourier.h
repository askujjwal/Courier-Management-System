#include <stdio.h>
#include <stdlib.h>

void addCourier(){
FILE *fp = fopen("couriers.txt", "a");
printf("Please enter the courier's name: ");
char name[100];
scanf("%s", name);
printf("Please enter the courier's phone number: ");
char phone[100];
scanf("%s", phone);
printf("Please enter the courier's address: ");
char address[100];
scanf("%s", address);
fprintf(fp, "%s %s %s\n", name, phone, address);
printf("Added!\n");
fclose(fp);
}