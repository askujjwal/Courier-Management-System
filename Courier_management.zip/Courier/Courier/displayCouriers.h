#include <stdio.h>

void displayCouriers(){
    FILE *fp = fopen("couriers.txt", "r");
    if(fp == NULL){
        printf("No courier records found.\n");
        return;
    }
    printf("Courier Name\t | Courier Phone\t | Courier Address\n");
    char name[100], address[100], phone[100];
    int i = 0;
    while(!feof(fp)){
        if (i!=0)
            printf("%s\t | %s\t | %s\n", name, phone, address);
        fscanf(fp, "%s %s %s", name, phone, address);
        i++;
        }
    fclose(fp);
}