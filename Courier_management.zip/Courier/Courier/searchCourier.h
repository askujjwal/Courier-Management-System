#include <stdio.h>

void searchCouriers(){
    FILE *fp = fopen("couriers.txt", "r");
    if(fp == NULL){
        printf("No courier records found.\n");
        return;
    }
    printf("Please enter the name of the courier you want to search for: ");
    char name[100];
    scanf("%s", name);
    int found = 0;
    while(!feof(fp)){
        char Cname[100], address[100], phone[100];
        fscanf(fp, "%s %s %s", Cname, address, phone);
        if(strcmp(name, Cname) == 0){
            printf("Courier Name\t | Courier Address\t | Courier Phone\n");
            printf("%s\t | %s\t | %s\n", name, address, phone);
            found = 1;
            break;
        }
    }
    if(!found){
        printf("No courier found with the name %s.\n", name);
    }
}