#include <stdio.h>
#include <string.h>

void addNewUser(char *username, char *password){
    FILE *fp = fopen("credentials.txt", "a");
    fprintf(fp, "%s %s\n", username, password);
    fclose(fp);
    printf("User added successfully!");
}

int checkUsername(char *name){
    FILE *fp = fopen("credentials.txt", "r");
    if(fp == NULL){
        return 0;
    }
    while(!feof(fp)){
        char username[100], password[100];
        fscanf(fp, "%s %s\n", username, password);
        if(strcmp(username, name) == 0){
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

int verifyCredentials(char *username, char *password){
    FILE *fp = fopen("credentials.txt", "r");
    while(!feof(fp)){
        char user[100], pass[100];
        fscanf(fp, "%s %s\n", user, pass);
        if(strcmp(user, username) == 0 && strcmp(pass, password) == 0){
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

