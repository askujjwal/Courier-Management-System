#include <stdio.h>
#include <stdlib.h>
#include "credentials.h"
#include "addCourier.h"
#include "displayCouriers.h"
#include "searchCourier.h"
#include "deleteUpdateCourier.h"
#include "sortCouriers.h"

void mainMenu(){
    printf("Please select an option:\n");
    printf("1. Add a new courier\n");
    printf("2. Display existing courier records\n");
    printf("3. Search for a courier\n");
    printf("4. Delete/Update a courier record\n");
    printf("5. Sort courier records\n");
    printf("6. Exit\n");
    printf("Please enter your choice: ");
    int choice;
    scanf("%d", &choice);
    switch(choice){
        case 1:
            addCourier();
            mainMenu();
            break;
        case 2:
            displayCouriers();
            mainMenu();
            break;
        case 3:
            searchCouriers();
            mainMenu();
            break;
        case 4:
            deleteUpdateCourier();
            mainMenu();
            break;
        case 5:
          sortCouriers();
          mainMenu();
          break;
        case 6:
            exit(0);
            break;
        default:
            printf("Invalid choice. Please try again.\n");
            mainMenu();
            break;  
    }
}

void login(){
    printf("Please enter your username: ");
    char username[20];
    scanf("%s", username);
    printf("Please enter your password: ");
    char password[20];
    scanf("%s", password);
    if (verifyCredentials(username, password)){
        printf("Login successful.\n");
        mainMenu();
    }
    else{
        printf("Invalid credentials. Please try again.\n");
        login();
    }
}

void newregister(){
    printf("Please enter your username: ");
    char username[20];
    scanf("%s", username);
    printf("Please enter your password: ");
    char password[20];
    scanf("%s", password);
    if (checkUsername(username)){
        printf("Username already exists. Please try again.\n");
        newregister();
    }
    else{
        addNewUser(username, password);
    }
}

int main(){
    printf("Welcome to the Courier Management System\n\n");
    printf("Would you like to login or register?\n");
    printf("1. Login\n");
    printf("2. Register\n");
    printf("3. Exit\n");
    printf("Please enter your choice: ");
    int choice;
    scanf("%d", &choice);
    switch(choice){
        case 1:
            login();
            break;
        case 2:
            newregister();
            break;
        case 3:
            exit(0);
            break;
        default:
            printf("Invalid choice. Please try again.\n");
            main();
            break;
    }
    

}